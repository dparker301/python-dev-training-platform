# Terraform: GitHub Actions OIDC to Assume AWS Role
Usage:
```
terraform init
terraform apply -var='github_org=<org>' -var='github_repo=<repo>' -var='aws_account_id=<acct>'
```
