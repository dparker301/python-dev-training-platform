# Lab: Local PostgreSQL (Docker) + psycopg
Run `docker compose up -d db` then `python main.py`.
