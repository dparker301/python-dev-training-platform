# Lab: SQLite ETL mini-pipeline
