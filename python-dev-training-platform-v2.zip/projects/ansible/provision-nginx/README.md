# Lab: Provision Nginx with Ansible

## Run
```bash
ansible-playbook -i inventory.ini site.yml
```
