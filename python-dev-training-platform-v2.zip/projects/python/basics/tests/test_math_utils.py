from app.math_utils import add

def test_add():
    assert add(2,3)==5
