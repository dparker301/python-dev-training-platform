# Lab: Python Warmup & Testing
- venv, pytest, flake8
- Implement a function and write tests

## Run
```bash
pip install -r ../../../../requirements.txt
pytest
```
