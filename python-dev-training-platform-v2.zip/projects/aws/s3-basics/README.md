# Lab: AWS S3 with boto3

## Run
```bash
python s3_demo.py --bucket <your-bucket> upload sample.txt
python s3_demo.py --bucket <your-bucket> list
python s3_demo.py --bucket <your-bucket> download sample.txt ./dl.txt
```
