# Lab: Hello Lambda (Python) + API Gateway
Zip and upload the function; map to HTTP API.
