# Lab: Flask Starter API + Templates

## Run
```bash
export FLASK_APP=app:app
flask run
```
