# Lab: FastAPI Starter (Async + OpenAPI)
Open http://127.0.0.1:8000/docs

## Run
```bash
uvicorn app:app --reload
```
