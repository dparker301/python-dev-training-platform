# Python Dev Training Platform (v2)

A modular, project-based scaffold to grow you from **junior → mid → senior** with Python across
Cloud (AWS), Web (Flask & FastAPI), Ansible, SQL (SQLite + Postgres), and CI/CD (GitHub Actions + Jenkins + GitLab),
with security (bandit, gitleaks, trivy) and Terraform OIDC for no-key AWS deploys.

## Quick Start
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python trainer.py list
python trainer.py start web/fastapi-starter
```

## Weekly Guides
See `guides/` for 90‑minute daily sprints packaged as Markdown (and DOCX when provided).
